package com.zhj;
import com.zhj.dao.DepartmentMapper;
import com.zhj.dao.EmployeeMapper;
import com.zhj.pojo.Department;
import com.zhj.pojo.Employee;
import com.zhj.service.EmployeeService;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.UUID;

/**
 * @author zhjstart
 * @create 2021-01-30 17:27
 */
/*@SpringJUnitConfig(locations = "classpath:applicationContext.xml")
public class MapperTest {
    @Autowired
    EmployeeService es;
    @Autowired
    EmployeeMapper em;
    @Autowired
    DepartmentMapper dm;
    @Autowired
    SqlSession sqlSession;
    @Test
    public void test() {

        List<Employee> emps = es.getAllEmps();
        System.out.println(emps);
    }
}*/
