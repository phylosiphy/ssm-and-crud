package com.zhj.pojo;

import com.github.pagehelper.PageInfo;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zhjstart
 * @create 2021-01-31 9:26
 */
public class MsgStatus {
    /*状态码：100成功，200失败*/
    private int code;
    /*提示信息*/
    private String msg;
    /*用户要给浏览器的数据*/
    private Map<String,Object> data = new HashMap<String,Object>();

    public static MsgStatus success(){
        MsgStatus result = new MsgStatus();
        result.setCode(100);
        result.setMsg("process successfully");
        return result;
    }

    public static MsgStatus failure(){
        MsgStatus result = new MsgStatus();
        result.setCode(200);
        result.setMsg("process unsuccessfully");
        return result;
    }


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    public MsgStatus add(String key, Object value) {
        this.getData().put(key,value);
        return this;
    }
}
