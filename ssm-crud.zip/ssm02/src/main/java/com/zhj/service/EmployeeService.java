package com.zhj.service;

import com.zhj.dao.EmployeeMapper;
import com.zhj.pojo.Employee;
import com.zhj.pojo.EmployeeExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author zhjstart
 * @create 2021-01-30 18:56
 */
@Service
public class EmployeeService {
    @Autowired
    EmployeeMapper em;

    public List<Employee> getAllEmps() {
        return em.selectByExampleWithDept(null);
    }
    /*员工保存方法*/
    public void saveEmp(Employee employee) {
        em.insertSelective(employee);
    }
    /*验证是否有同名方法*/
    public boolean checkUsername(String empName) {
        EmployeeExample ee = new EmployeeExample();
        EmployeeExample.Criteria criteria = ee.createCriteria();
        criteria.andEmpNameEqualTo(empName);
        long l = em.countByExample(ee);
        return l == 0;
    }
    /*根据id查员工*/
    public Employee getEmp(Integer id) {

        return em.selectByPrimaryKey(id);
    }

    public void updateEmp(Employee employee) {
        em.updateByPrimaryKeySelective(employee);
    }

    public void deleteEmp(Integer id) {
        em.deleteByPrimaryKey(id);
    }

    public void deleteBatch(List<Integer> split) {
        EmployeeExample example = new EmployeeExample();
        EmployeeExample.Criteria criteria = example.createCriteria();
        criteria.andEmpIdIn(split);
        em.deleteByExample(example);
    }
}
