package com.zhj.service;

import com.zhj.dao.DepartmentMapper;
import com.zhj.pojo.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author zhjstart
 * @create 2021-01-31 12:20
 */
@Service
public class DepartmentService {
    @Autowired
    private DepartmentMapper dm;

    public List<Department> getDepts() {
        List<Department> departments = dm.selectByExample(null);
        return departments;
    }
}
