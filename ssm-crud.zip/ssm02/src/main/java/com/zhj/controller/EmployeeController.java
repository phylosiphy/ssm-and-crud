package com.zhj.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zhj.pojo.Employee;
import com.zhj.pojo.MsgStatus;
import com.zhj.service.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * 处理员工CRUD请求
 * @author zhjstart
 * @create 2021-01-30 18:52
 */
@Controller
public class EmployeeController {
    @Autowired
    EmployeeService es;

    /**
     * 批量删除
     */
    @ResponseBody
    @RequestMapping(value = "/emps/{empId}",method = RequestMethod.DELETE)
    public MsgStatus delelteEempById(@PathVariable("empId") String ids){
        String[] split = ids.split("-");
        ArrayList<Integer> list = new ArrayList<Integer>();
        for(String sp : split){
            list.add(Integer.parseInt(sp));
        }
         es.deleteBatch(list);
        return MsgStatus.success();
    }

    /**
     * 单个删除
     * 单个：1
     * @param id
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/emp/{empId}",method = RequestMethod.DELETE)
    public MsgStatus delelteEempById(@PathVariable("empId") Integer id){
        es.deleteEmp(id);
        return MsgStatus.success();
    }

    /**
     * 更新员工信息
     * @param employee
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/emp/{empId}",method = RequestMethod.PUT)
    public MsgStatus saveEmp(Employee employee){
        es.updateEmp(employee);
        return MsgStatus.success();
    }

    /**
     * 根据id查员工
     * @param id
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/emp/{id}",method = RequestMethod.GET)
    public MsgStatus getEmp(@PathVariable("id") Integer id){
        Employee employee = es.getEmp(id);
        return MsgStatus.success().add("emp",employee);
    }

    /**
     * 校验用户名是否可用
     * @param empName
     * @return
     */
    @RequestMapping("/checkUsername")
    @ResponseBody
    public MsgStatus checkUsername(@RequestParam("empName") String empName){
        //先判断用户名是否合法
        String regx = "(^[a-zA-Z0-9_-]{6,16}$)|(^[\u2E80-\u9FFF]{2,8}$)";
        boolean matches = empName.matches(regx);
        if(!matches){
            return MsgStatus.failure().add("va_msg","用户名必须是6到16位或其它");
        }
        //进行数据库校验
        boolean isTrue = es.checkUsername(empName);
        if(isTrue){
            return MsgStatus.success();
        }else {
            return MsgStatus.failure().add("va_msg","用户名不可用");
        }
    }

    /**
     * 增加一个员工
     * @return
     */
    @RequestMapping(value = "/emp",method = RequestMethod.POST)
    @ResponseBody
    public MsgStatus saveEmp(@Valid Employee employee, BindingResult result){
        if(result.hasErrors()){
            //校验失败
            Map<String,Object> map= new HashMap<String, Object>();
            List<FieldError> errors = result.getFieldErrors();
            for(FieldError error:errors){
                System.out.println("错误的字段名:"+error.getField());
                System.out.println("错误的字段名:"+error.getDefaultMessage());
                map.put(error.getField(),error.getDefaultMessage());
            }
            return MsgStatus.failure().add("errorFields",map);
        }else {
            es.saveEmp(employee);
            return MsgStatus.success();
        }
    }

    /**
     * 使用ajax请求获取所有分页信息
     */
    @ResponseBody
    @RequestMapping("/emps")
    public MsgStatus getEmpsWithJson(@RequestParam(value = "pn",defaultValue = "1")Integer pn){
        PageHelper.startPage(pn,5);
        //现在就是分页查询
        List<Employee> emps = es.getAllEmps();
        //使用pageinfo包装查询结果,只要将pageinfo交给页面，里面封装了详细信息
        //连续显示的页数
        PageInfo page = new PageInfo(emps,6);
        return MsgStatus.success().add("pageInfo",page);
    }

    /**
     * 获取所有员工
     * @return
     */
  /*  @RequestMapping("/emps")
    public String getAllEmps(@RequestParam(value = "pn",defaultValue = "1")Integer pn,Model model){
        *//*引入pagehelper插件，在查询之前调用,传入页码数及每页大小*//*
        PageHelper.startPage(pn,5);
        *//*现在就是分页查询*//*
        List<Employee> emps = es.getAllEmps();
        *//*使用pageinfo包装查询结果,只要将pageinfo交给页面，里面封装了详细信息*//*
        *//*连续显示的页数*//*
        PageInfo page = new PageInfo(emps,6);
        model.addAttribute("pageInfo",page);
        return "list";
    }*/

}
