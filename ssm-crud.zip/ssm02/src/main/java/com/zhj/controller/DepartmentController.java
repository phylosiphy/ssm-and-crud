package com.zhj.controller;

import com.zhj.pojo.Department;
import com.zhj.pojo.MsgStatus;
import com.zhj.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 处理和部门有关的请求
 * @author zhjstart
 * @create 2021-01-31 11:39
 */
@Controller
public class DepartmentController {
    @Autowired
    private DepartmentService ds;

    /**
     * 返回所有部门信息
     * @return
     */
    @ResponseBody
    @RequestMapping("depts")
    public MsgStatus getDepts(){
        List<Department> depts = ds.getDepts();
        return MsgStatus.success().add("depts",depts);
    }
}
